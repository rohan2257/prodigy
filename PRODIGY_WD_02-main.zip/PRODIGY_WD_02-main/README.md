# PRODIGY_WD_02
## StopWatch Web Application
---
<p> Task - To build a stopwatch web application, Here I use HTML, CSS, and JavaScript. HTML is used to structure the elements of the application. By implementing functions for starting, pausing, and resetting the stopwatch, as well as tracking and <b> displaying lap times </b>, users can accurately measure and record time intervals. With these technologies and functionalities, I have create an interactive and user-friendly stopwatch web application. </p>

<p> Languages Used: HTML, CSS, & JavaScript </p>
<h2>Preview: </h2>
<p>This is preview of the project. You can visit live preview on <a href="https://deblinaroy11.github.io/PRODIGY_WD_02/" target="_blank"> Here. </a></p>






https://github.com/deblinaroy11/PRODIGY_WD_02/assets/137715845/c183c7f8-f57c-4cfe-a5bb-ec0efc48f71f



<h2>Code: </h2>








https://github.com/deblinaroy11/PRODIGY_WD_02/assets/137715845/8921bc72-846a-469b-8a4e-1baede8fb5ac

